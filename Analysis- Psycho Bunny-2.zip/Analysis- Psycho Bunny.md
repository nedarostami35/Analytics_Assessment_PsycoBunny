# Data Analysis - Product Insight


```python
# Reading in the initial data

import pandas as pd
import matplotlib.pyplot as plt




Data = pd.read_csv("Sales.csv")
Fiscal_Calendar =  pd.read_csv("de_dates.csv")    

```


```python
Data.head()
Fiscal_Calendar.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CALENDAR_DATE</th>
      <th>WEEKDAY_NUMBER</th>
      <th>WEEKDAY_NAME</th>
      <th>FISCAL_WEEK_OF_MONTH</th>
      <th>FISCAL_WEEK_OF_YEAR</th>
      <th>FISCAL_MONTH_NUMBER</th>
      <th>FISCAL_MONTH_NAME</th>
      <th>FISCAL_FIRST_DAY_OF_WEEK</th>
      <th>FISCAL_LAST_DAY_OF_WEEK</th>
      <th>FISCAL_FIRST_DAY_OF_MONTH</th>
      <th>...</th>
      <th>FISCAL_YEAR_WEEK</th>
      <th>FISCAL_YEAR_MONTH</th>
      <th>FISCAL_YEAR_QUARTER</th>
      <th>CALENDAR_WEEK_OF_MONTH</th>
      <th>CALENDAR_WEEK_OF_YEAR</th>
      <th>CALENDAR_FIRST_DAY_OF_MONTH</th>
      <th>CALENDAR_LAST_DAY_OF_MONTH</th>
      <th>CALENDAR_FIRST_DAY_OF_YEAR</th>
      <th>CALENDAR_LAST_DAY_OF_YEAR</th>
      <th>WEEKEND</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2010-01-31</td>
      <td>1</td>
      <td>Sun</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>Feb</td>
      <td>2010-01-31</td>
      <td>2010-02-06</td>
      <td>2010-01-31</td>
      <td>...</td>
      <td>201001</td>
      <td>201001</td>
      <td>20101</td>
      <td>5</td>
      <td>4</td>
      <td>2010-01-01</td>
      <td>2010-01-31</td>
      <td>2010-01-01</td>
      <td>2010-12-31</td>
      <td>True</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2010-02-01</td>
      <td>2</td>
      <td>Mon</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>Feb</td>
      <td>2010-01-31</td>
      <td>2010-02-06</td>
      <td>2010-01-31</td>
      <td>...</td>
      <td>201001</td>
      <td>201001</td>
      <td>20101</td>
      <td>1</td>
      <td>5</td>
      <td>2010-02-01</td>
      <td>2010-02-28</td>
      <td>2010-01-01</td>
      <td>2010-12-31</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2010-02-02</td>
      <td>3</td>
      <td>Tue</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>Feb</td>
      <td>2010-01-31</td>
      <td>2010-02-06</td>
      <td>2010-01-31</td>
      <td>...</td>
      <td>201001</td>
      <td>201001</td>
      <td>20101</td>
      <td>1</td>
      <td>5</td>
      <td>2010-02-01</td>
      <td>2010-02-28</td>
      <td>2010-01-01</td>
      <td>2010-12-31</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2010-02-03</td>
      <td>4</td>
      <td>Wed</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>Feb</td>
      <td>2010-01-31</td>
      <td>2010-02-06</td>
      <td>2010-01-31</td>
      <td>...</td>
      <td>201001</td>
      <td>201001</td>
      <td>20101</td>
      <td>1</td>
      <td>5</td>
      <td>2010-02-01</td>
      <td>2010-02-28</td>
      <td>2010-01-01</td>
      <td>2010-12-31</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2010-02-04</td>
      <td>5</td>
      <td>Thu</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>Feb</td>
      <td>2010-01-31</td>
      <td>2010-02-06</td>
      <td>2010-01-31</td>
      <td>...</td>
      <td>201001</td>
      <td>201001</td>
      <td>20101</td>
      <td>1</td>
      <td>5</td>
      <td>2010-02-01</td>
      <td>2010-02-28</td>
      <td>2010-01-01</td>
      <td>2010-12-31</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 24 columns</p>
</div>




```python
Fiscal_Calendar.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CALENDAR_DATE</th>
      <th>WEEKDAY_NUMBER</th>
      <th>WEEKDAY_NAME</th>
      <th>FISCAL_WEEK_OF_MONTH</th>
      <th>FISCAL_WEEK_OF_YEAR</th>
      <th>FISCAL_MONTH_NUMBER</th>
      <th>FISCAL_MONTH_NAME</th>
      <th>FISCAL_FIRST_DAY_OF_WEEK</th>
      <th>FISCAL_LAST_DAY_OF_WEEK</th>
      <th>FISCAL_FIRST_DAY_OF_MONTH</th>
      <th>...</th>
      <th>FISCAL_YEAR_WEEK</th>
      <th>FISCAL_YEAR_MONTH</th>
      <th>FISCAL_YEAR_QUARTER</th>
      <th>CALENDAR_WEEK_OF_MONTH</th>
      <th>CALENDAR_WEEK_OF_YEAR</th>
      <th>CALENDAR_FIRST_DAY_OF_MONTH</th>
      <th>CALENDAR_LAST_DAY_OF_MONTH</th>
      <th>CALENDAR_FIRST_DAY_OF_YEAR</th>
      <th>CALENDAR_LAST_DAY_OF_YEAR</th>
      <th>WEEKEND</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2010-01-31</td>
      <td>1</td>
      <td>Sun</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>Feb</td>
      <td>2010-01-31</td>
      <td>2010-02-06</td>
      <td>2010-01-31</td>
      <td>...</td>
      <td>201001</td>
      <td>201001</td>
      <td>20101</td>
      <td>5</td>
      <td>4</td>
      <td>2010-01-01</td>
      <td>2010-01-31</td>
      <td>2010-01-01</td>
      <td>2010-12-31</td>
      <td>True</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2010-02-01</td>
      <td>2</td>
      <td>Mon</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>Feb</td>
      <td>2010-01-31</td>
      <td>2010-02-06</td>
      <td>2010-01-31</td>
      <td>...</td>
      <td>201001</td>
      <td>201001</td>
      <td>20101</td>
      <td>1</td>
      <td>5</td>
      <td>2010-02-01</td>
      <td>2010-02-28</td>
      <td>2010-01-01</td>
      <td>2010-12-31</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2010-02-02</td>
      <td>3</td>
      <td>Tue</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>Feb</td>
      <td>2010-01-31</td>
      <td>2010-02-06</td>
      <td>2010-01-31</td>
      <td>...</td>
      <td>201001</td>
      <td>201001</td>
      <td>20101</td>
      <td>1</td>
      <td>5</td>
      <td>2010-02-01</td>
      <td>2010-02-28</td>
      <td>2010-01-01</td>
      <td>2010-12-31</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2010-02-03</td>
      <td>4</td>
      <td>Wed</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>Feb</td>
      <td>2010-01-31</td>
      <td>2010-02-06</td>
      <td>2010-01-31</td>
      <td>...</td>
      <td>201001</td>
      <td>201001</td>
      <td>20101</td>
      <td>1</td>
      <td>5</td>
      <td>2010-02-01</td>
      <td>2010-02-28</td>
      <td>2010-01-01</td>
      <td>2010-12-31</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2010-02-04</td>
      <td>5</td>
      <td>Thu</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>Feb</td>
      <td>2010-01-31</td>
      <td>2010-02-06</td>
      <td>2010-01-31</td>
      <td>...</td>
      <td>201001</td>
      <td>201001</td>
      <td>20101</td>
      <td>1</td>
      <td>5</td>
      <td>2010-02-01</td>
      <td>2010-02-28</td>
      <td>2010-01-01</td>
      <td>2010-12-31</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 24 columns</p>
</div>




```python
# Handling missing values
Data.fillna(0, inplace=True)
Fiscal_Calendar.fillna(0, inplace=True)

# Convert TRANSACTION_DATE to datetime format
Data['TRANSACTION_DATE'] = pd.to_datetime(Data['TRANSACTION_DATE'], errors='coerce')
Data.dropna(subset=['TRANSACTION_DATE'], inplace=True)

```


```python
# Format numeric values
Data['NET_SALES_UNITS'] = Data['NET_SALES_UNITS'].astype(int)
Data['ORIGINAL_PRICE'] = Data['ORIGINAL_PRICE'].astype(float)
Data['DISCOUNTS_USD'] = Data['DISCOUNTS_USD'].astype(float)

```


```python
# Identify outliers using IQR method for NET_SALES_UNITS
Q1 = Data['NET_SALES_UNITS'].quantile(0.25)
Q3 = Data['NET_SALES_UNITS'].quantile(0.75)
IQR = Q3 - Q1

outliers = Data[(Data['NET_SALES_UNITS'] < (Q1 - 1.5 * IQR)) | (Data['NET_SALES_UNITS'] > (Q3 + 1.5 * IQR))]

```


```python
# Convert date columns to datetime format
Data['TRANSACTION_DATE'] = pd.to_datetime(Data['TRANSACTION_DATE'], errors='coerce')
Fiscal_Calendar['CALENDAR_DATE'] = pd.to_datetime(Fiscal_Calendar['CALENDAR_DATE'], errors='coerce')

```


```python
# Merge sales_data with fiscal_calendar
merged_data = pd.merge(Data, Fiscal_Calendar, left_on='TRANSACTION_DATE', right_on='CALENDAR_DATE', how='left')

```


```python
# Display the first few rows of the merged dataset
merged_data_head = merged_data.head()
merged_data_head

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>TRANSACTION_DATE</th>
      <th>LOCATION_ID</th>
      <th>ORDER_ID</th>
      <th>CUSTOMER_ID</th>
      <th>SKU_NUMBER</th>
      <th>STYLE_NUMBER</th>
      <th>COLOUR_NAME</th>
      <th>COLOUR_NUMBER</th>
      <th>COLOUR_CODE</th>
      <th>COLOUR_FAMILY</th>
      <th>...</th>
      <th>FISCAL_YEAR_WEEK</th>
      <th>FISCAL_YEAR_MONTH</th>
      <th>FISCAL_YEAR_QUARTER</th>
      <th>CALENDAR_WEEK_OF_MONTH</th>
      <th>CALENDAR_WEEK_OF_YEAR</th>
      <th>CALENDAR_FIRST_DAY_OF_MONTH</th>
      <th>CALENDAR_LAST_DAY_OF_MONTH</th>
      <th>CALENDAR_FIRST_DAY_OF_YEAR</th>
      <th>CALENDAR_LAST_DAY_OF_YEAR</th>
      <th>WEEKEND</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2023-09-15</td>
      <td>5381359054857415170</td>
      <td>-6719308655116430000</td>
      <td>2615747808920676222</td>
      <td>-7253962859621530000</td>
      <td>-4147267151382690000</td>
      <td>WHITE</td>
      <td>-7990442703153960000</td>
      <td>WHT</td>
      <td>WHITE</td>
      <td>...</td>
      <td>202333</td>
      <td>202308</td>
      <td>20233</td>
      <td>3</td>
      <td>37</td>
      <td>2023-09-01</td>
      <td>2023-09-30</td>
      <td>2023-01-01</td>
      <td>2023-12-31</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2022-03-18</td>
      <td>-4199173001801520000</td>
      <td>-6378926798744470000</td>
      <td>1887452110738807739</td>
      <td>5422249653400898675</td>
      <td>-313994741047813000</td>
      <td>VIVID VIOLET</td>
      <td>6700927323266645156</td>
      <td>VVV</td>
      <td>PURPLE</td>
      <td>...</td>
      <td>202207</td>
      <td>202202</td>
      <td>20221</td>
      <td>3</td>
      <td>11</td>
      <td>2022-03-01</td>
      <td>2022-03-31</td>
      <td>2022-01-01</td>
      <td>2022-12-31</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2023-07-14</td>
      <td>5685263721614244213</td>
      <td>6102719515008744276</td>
      <td>-1296229179810210000</td>
      <td>6245575513011636165</td>
      <td>-4724890390615580000</td>
      <td>NAVY</td>
      <td>-1334537463826090000</td>
      <td>NVY</td>
      <td>NAVY</td>
      <td>...</td>
      <td>202324</td>
      <td>202306</td>
      <td>20232</td>
      <td>3</td>
      <td>28</td>
      <td>2023-07-01</td>
      <td>2023-07-31</td>
      <td>2023-01-01</td>
      <td>2023-12-31</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2022-04-06</td>
      <td>-5067008464076210000</td>
      <td>-5982285096719080000</td>
      <td>-2738066512337320000</td>
      <td>-8479039255313250000</td>
      <td>-1553484492876750000</td>
      <td>NAVY</td>
      <td>-1334537463826090000</td>
      <td>NVY</td>
      <td>NAVY</td>
      <td>...</td>
      <td>202210</td>
      <td>202203</td>
      <td>20221</td>
      <td>2</td>
      <td>14</td>
      <td>2022-04-01</td>
      <td>2022-04-30</td>
      <td>2022-01-01</td>
      <td>2022-12-31</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2023-06-12</td>
      <td>-5591079094253810000</td>
      <td>-3971618995716690000</td>
      <td>-4612109181828620000</td>
      <td>3357108323404969175</td>
      <td>-3145342290914690000</td>
      <td>BLACK</td>
      <td>-4199173001801520000</td>
      <td>BLK</td>
      <td>BLACK</td>
      <td>...</td>
      <td>202320</td>
      <td>202305</td>
      <td>20232</td>
      <td>3</td>
      <td>24</td>
      <td>2023-06-01</td>
      <td>2023-06-30</td>
      <td>2023-01-01</td>
      <td>2023-12-31</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 45 columns</p>
</div>



Total Sales Over Time



```python
import matplotlib.pyplot as plt

# Convert TRANSACTION_DATE to datetime formatData['TRANSACTION_DATE'] = pd.to_datetime(sales_data['TRANSACTION_DATE'])

# Group by transaction date to get total sales per day
sales_over_time = Data.groupby('TRANSACTION_DATE')['NET_SALES_UNITS'].sum()

# Plot total sales over time
plt.figure(figsize=(12, 6))
sales_over_time.plot()
plt.title('Total Sales Over Time')
plt.xlabel('Date')
plt.ylabel('Total Sales Units')
plt.grid(True)
plt.show()

```


    
![png](output_11_0.png)
    


Sales by Product Type



```python
# Group by product type to get total sales
sales_by_product_type = Data.groupby('PRODUCT_TYPE')['NET_SALES_UNITS'].sum()

# Plot sales by product type
plt.figure(figsize=(12, 6))
sales_by_product_type.plot(kind='bar')
plt.title('Sales by Product Type')
plt.xlabel('Product Type')
plt.ylabel('Total Sales Units')
plt.grid(True)
plt.show()

```


    
![png](output_13_0.png)
    



```python
# Group by FIT to get total sales
sales_by_fit = merged_data.groupby('FIT')['NET_SALES_UNITS'].sum()

# Plot sales by fit
plt.figure(figsize=(12, 6))
sales_by_fit.plot(kind='bar', color='lightblue')
plt.title('Sales by Fit')
plt.xlabel('Fit')
plt.ylabel('Total Sales Units')
plt.grid(True)
plt.show()

```


    
![png](output_14_0.png)
    



```python


```


```python
# Group by SIZE to get total sales
sales_by_size = merged_data.groupby('SIZE')['NET_SALES_UNITS'].sum()

# Plot sales by size
plt.figure(figsize=(12, 6))
sales_by_size.plot(kind='bar', color='lightblue')
plt.title('Sales by Size')
plt.xlabel('Size')
plt.ylabel('Total Sales Units')
plt.grid(True)
plt.show()

```


    
![png](output_16_0.png)
    



```python
pip install statsmodels

```

    Requirement already satisfied: statsmodels in /Users/nedarostami/anaconda3/lib/python3.11/site-packages (0.14.0)
    Requirement already satisfied: numpy>=1.18 in /Users/nedarostami/anaconda3/lib/python3.11/site-packages (from statsmodels) (1.24.3)
    Requirement already satisfied: scipy!=1.9.2,>=1.4 in /Users/nedarostami/anaconda3/lib/python3.11/site-packages (from statsmodels) (1.11.1)
    Requirement already satisfied: pandas>=1.0 in /Users/nedarostami/anaconda3/lib/python3.11/site-packages (from statsmodels) (2.0.3)
    Requirement already satisfied: patsy>=0.5.2 in /Users/nedarostami/anaconda3/lib/python3.11/site-packages (from statsmodels) (0.5.3)
    Requirement already satisfied: packaging>=21.3 in /Users/nedarostami/anaconda3/lib/python3.11/site-packages (from statsmodels) (23.1)
    Requirement already satisfied: python-dateutil>=2.8.2 in /Users/nedarostami/anaconda3/lib/python3.11/site-packages (from pandas>=1.0->statsmodels) (2.8.2)
    Requirement already satisfied: pytz>=2020.1 in /Users/nedarostami/anaconda3/lib/python3.11/site-packages (from pandas>=1.0->statsmodels) (2023.3.post1)
    Requirement already satisfied: tzdata>=2022.1 in /Users/nedarostami/anaconda3/lib/python3.11/site-packages (from pandas>=1.0->statsmodels) (2023.3)
    Requirement already satisfied: six in /Users/nedarostami/anaconda3/lib/python3.11/site-packages (from patsy>=0.5.2->statsmodels) (1.16.0)
    Note: you may need to restart the kernel to use updated packages.


 Sales Prediction



```python
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.arima.model import ARIMA

# Sample data to simulate the merged data
data = {
    'TRANSACTION_DATE': pd.date_range(start='1/1/2022', periods=200, freq='D').tolist() +
                        pd.date_range(start='1/1/2023', periods=200, freq='D').tolist(),
    'NET_SALES_UNITS': [5, 10, 15, 20, 25, 30, 35, 40, 45, 50] * 40
}

# Create DataFrame
merged_data = pd.DataFrame(data)

# Step 1: Prepare the Data
# Convert TRANSACTION_DATE to datetime format
merged_data['TRANSACTION_DATE'] = pd.to_datetime(merged_data['TRANSACTION_DATE'])

# Aggregate sales by month
monthly_sales = merged_data.groupby(merged_data['TRANSACTION_DATE'].dt.to_period('M'))['NET_SALES_UNITS'].sum()

# Convert to datetime index
monthly_sales.index = monthly_sales.index.to_timestamp()

# Step 2: Fit the ARIMA Model
model = ARIMA(monthly_sales, order=(5, 1, 0))
model_fit = model.fit()

# Step 3: Make Predictions
forecast = model_fit.forecast(steps=12)
forecast_index = pd.date_range(start='2024-01-01', periods=12, freq='M')

# Plot the historical sales and the forecast
plt.figure(figsize=(12, 6))
plt.plot(monthly_sales.index, monthly_sales, label='Historical Sales')
plt.plot(forecast_index, forecast, label='Forecasted Sales', color='red')
plt.title('Sales Forecast for 2024')
plt.xlabel('Date')
plt.ylabel('Total Sales Units')
plt.legend()
plt.grid(True)
plt.show()

```

    /Users/nedarostami/anaconda3/lib/python3.11/site-packages/statsmodels/tsa/base/tsa_model.py:473: ValueWarning: A date index has been provided, but it has no associated frequency information and so will be ignored when e.g. forecasting.
      self._init_dates(dates, freq)
    /Users/nedarostami/anaconda3/lib/python3.11/site-packages/statsmodels/tsa/base/tsa_model.py:473: ValueWarning: A date index has been provided, but it has no associated frequency information and so will be ignored when e.g. forecasting.
      self._init_dates(dates, freq)
    /Users/nedarostami/anaconda3/lib/python3.11/site-packages/statsmodels/tsa/base/tsa_model.py:473: ValueWarning: A date index has been provided, but it has no associated frequency information and so will be ignored when e.g. forecasting.
      self._init_dates(dates, freq)
    /Users/nedarostami/anaconda3/lib/python3.11/site-packages/statsmodels/tsa/base/tsa_model.py:836: ValueWarning: No supported index is available. Prediction results will be given with an integer index beginning at `start`.
      return get_prediction_index(
    /Users/nedarostami/anaconda3/lib/python3.11/site-packages/statsmodels/tsa/base/tsa_model.py:836: FutureWarning: No supported index is available. In the next version, calling this method in a model without a supported index will result in an exception.
      return get_prediction_index(



    
![png](output_19_1.png)
    



```python
pip install statsmodels

```

    Requirement already satisfied: statsmodels in /Users/nedarostami/anaconda3/lib/python3.11/site-packages (0.14.0)
    Requirement already satisfied: numpy>=1.18 in /Users/nedarostami/anaconda3/lib/python3.11/site-packages (from statsmodels) (1.24.3)
    Requirement already satisfied: scipy!=1.9.2,>=1.4 in /Users/nedarostami/anaconda3/lib/python3.11/site-packages (from statsmodels) (1.11.1)
    Requirement already satisfied: pandas>=1.0 in /Users/nedarostami/anaconda3/lib/python3.11/site-packages (from statsmodels) (2.0.3)
    Requirement already satisfied: patsy>=0.5.2 in /Users/nedarostami/anaconda3/lib/python3.11/site-packages (from statsmodels) (0.5.3)
    Requirement already satisfied: packaging>=21.3 in /Users/nedarostami/anaconda3/lib/python3.11/site-packages (from statsmodels) (23.1)
    Requirement already satisfied: python-dateutil>=2.8.2 in /Users/nedarostami/anaconda3/lib/python3.11/site-packages (from pandas>=1.0->statsmodels) (2.8.2)
    Requirement already satisfied: pytz>=2020.1 in /Users/nedarostami/anaconda3/lib/python3.11/site-packages (from pandas>=1.0->statsmodels) (2023.3.post1)
    Requirement already satisfied: tzdata>=2022.1 in /Users/nedarostami/anaconda3/lib/python3.11/site-packages (from pandas>=1.0->statsmodels) (2023.3)
    Requirement already satisfied: six in /Users/nedarostami/anaconda3/lib/python3.11/site-packages (from patsy>=0.5.2->statsmodels) (1.16.0)
    Note: you may need to restart the kernel to use updated packages.



```python
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.arima.model import ARIMA

# Sample data to simulate the merged data
dates = pd.date_range(start='1/1/2022', periods=500, freq='D')
categories = ['Fashion', 'Core', 'Fashion Basic']
sales_units = [5, 10, 15]

# Create lists with the correct lengths
transaction_dates = dates.tolist() * 3
product_categories = categories * (len(transaction_dates) // len(categories))
net_sales_units = sales_units * (len(transaction_dates) // len(sales_units))

# Create DataFrame
data = {
    'TRANSACTION_DATE': transaction_dates,
    'PRODUCT_CATEGORY': product_categories,
    'NET_SALES_UNITS': net_sales_units
}

merged_data = pd.DataFrame(data)

# Convert TRANSACTION_DATE to datetime format
merged_data['TRANSACTION_DATE'] = pd.to_datetime(merged_data['TRANSACTION_DATE'])

# Function to forecast sales for each product category
def forecast_sales_by_category(data, category):
    # Filter data for the specific category
    category_data = data[data['PRODUCT_CATEGORY'] == category]
    
    # Aggregate sales by month
    monthly_sales = category_data.groupby(category_data['TRANSACTION_DATE'].dt.to_period('M'))['NET_SALES_UNITS'].sum()
    
    # Convert to datetime index
    monthly_sales.index = monthly_sales.index.to_timestamp()
    
    # Fit ARIMA model on full data
    model = ARIMA(monthly_sales, order=(5, 1, 0))
    model_fit = model.fit()
    
    # Forecast for 2024 (12 months)
    forecast = model_fit.forecast(steps=12)
    forecast_index = pd.date_range(start='2024-01-01', periods=12, freq='M')
    
    return monthly_sales, forecast, forecast_index

# Forecast sales for each product category and combine forecasts
categories = merged_data['PRODUCT_CATEGORY'].unique()
combined_forecast = pd.Series(dtype='float64')
all_forecasts = {}
historical_data = {}

for category in categories:
    historical, forecast, forecast_index = forecast_sales_by_category(merged_data, category)
    combined_forecast = combined_forecast.add(pd.Series(forecast.values, index=forecast_index), fill_value=0)
    all_forecasts[category] = (historical, forecast, forecast_index)
    historical_data[category] = historical

# Plot all forecasts in one chart
plt.figure(figsize=(14, 8))

for category in categories:
    historical, forecast, forecast_index = all_forecasts[category]
    plt.plot(historical.index, historical, label=f'Historical Sales ({category})')
    plt.plot(forecast_index, forecast, label=f'Forecasted Sales ({category})', linestyle='dashed')

plt.plot(combined_forecast.index, combined_forecast, label='Combined Forecasted Sales', color='blue', linewidth=2)
plt.title('Sales Forecast for 2024 by Product Category')
plt.xlabel('Date')
plt.ylabel('Total Sales Units')
plt.legend()
plt.grid(True)
plt.show()

```

    /Users/nedarostami/anaconda3/lib/python3.11/site-packages/statsmodels/tsa/statespace/sarimax.py:966: UserWarning: Non-stationary starting autoregressive parameters found. Using zeros as starting parameters.
      warn('Non-stationary starting autoregressive parameters'
    /Users/nedarostami/anaconda3/lib/python3.11/site-packages/statsmodels/tsa/statespace/sarimax.py:966: UserWarning: Non-stationary starting autoregressive parameters found. Using zeros as starting parameters.
      warn('Non-stationary starting autoregressive parameters'
    /Users/nedarostami/anaconda3/lib/python3.11/site-packages/statsmodels/tsa/statespace/sarimax.py:966: UserWarning: Non-stationary starting autoregressive parameters found. Using zeros as starting parameters.
      warn('Non-stationary starting autoregressive parameters'



    
![png](output_21_1.png)
    


Sales by Location Type



```python
# Ensure the Location_Type column is added correctly
Data['Location_Type'] = Data['LOCATION_ID'].apply(
    lambda x: 'eCommerce' if x == -4199173001801520000 else 'Brick and Mortar'
)

# Verify the Location_Type column
sales_data_head_with_location_type = Data.head()

# Group by location type to get total sales
sales_by_location_type = Data.groupby('Location_Type')['NET_SALES_UNITS'].sum()

# Plot sales by location type
plt.figure(figsize=(12, 6))
sales_by_location_type.plot(kind='bar')
plt.title('Sales by Location Type')
plt.xlabel('Location Type')
plt.ylabel('Total Sales Units')
plt.grid(True)
plt.show()

sales_data_head_with_location_type

```


    
![png](output_23_0.png)
    





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>TRANSACTION_DATE</th>
      <th>LOCATION_ID</th>
      <th>ORDER_ID</th>
      <th>CUSTOMER_ID</th>
      <th>SKU_NUMBER</th>
      <th>STYLE_NUMBER</th>
      <th>COLOUR_NAME</th>
      <th>COLOUR_NUMBER</th>
      <th>COLOUR_CODE</th>
      <th>COLOUR_FAMILY</th>
      <th>...</th>
      <th>FIT</th>
      <th>PRODUCT_TYPE</th>
      <th>LOGO_TYPE</th>
      <th>SIZE</th>
      <th>BUSINESS</th>
      <th>GROUP</th>
      <th>ORIGINAL_PRICE</th>
      <th>DISCOUNTS_USD</th>
      <th>NET_SALES_UNITS</th>
      <th>Location_Type</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2023-09-15</td>
      <td>5381359054857415170</td>
      <td>-6719308655116430000</td>
      <td>2615747808920676222</td>
      <td>-7253962859621530000</td>
      <td>-4147267151382690000</td>
      <td>WHITE</td>
      <td>-7990442703153960000</td>
      <td>WHT</td>
      <td>WHITE</td>
      <td>...</td>
      <td>REGULAR</td>
      <td>FASHION</td>
      <td>FASHION</td>
      <td>M</td>
      <td>MENS</td>
      <td>TOPS</td>
      <td>32.88</td>
      <td>0.00</td>
      <td>1</td>
      <td>Brick and Mortar</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2022-03-18</td>
      <td>-4199173001801520000</td>
      <td>-6378926798744470000</td>
      <td>1887452110738807739</td>
      <td>5422249653400898675</td>
      <td>-313994741047813000</td>
      <td>VIVID VIOLET</td>
      <td>6700927323266645156</td>
      <td>VVV</td>
      <td>PURPLE</td>
      <td>...</td>
      <td>REGULAR</td>
      <td>FASHION BASIC</td>
      <td>CLASSIC</td>
      <td>XL</td>
      <td>MENS</td>
      <td>TOPS</td>
      <td>32.88</td>
      <td>0.00</td>
      <td>1</td>
      <td>eCommerce</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2023-07-14</td>
      <td>5685263721614244213</td>
      <td>6102719515008744276</td>
      <td>-1296229179810210000</td>
      <td>6245575513011636165</td>
      <td>-4724890390615580000</td>
      <td>NAVY</td>
      <td>-1334537463826090000</td>
      <td>NVY</td>
      <td>NAVY</td>
      <td>...</td>
      <td>REGULAR</td>
      <td>FASHION</td>
      <td>FASHION</td>
      <td>L</td>
      <td>MENS</td>
      <td>TOPS</td>
      <td>32.88</td>
      <td>0.00</td>
      <td>1</td>
      <td>Brick and Mortar</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2022-04-06</td>
      <td>-5067008464076210000</td>
      <td>-5982285096719080000</td>
      <td>-2738066512337320000</td>
      <td>-8479039255313250000</td>
      <td>-1553484492876750000</td>
      <td>NAVY</td>
      <td>-1334537463826090000</td>
      <td>NVY</td>
      <td>NAVY</td>
      <td>...</td>
      <td>REGULAR</td>
      <td>FASHION</td>
      <td>FASHION</td>
      <td>L</td>
      <td>MENS</td>
      <td>TOPS</td>
      <td>32.88</td>
      <td>1.21</td>
      <td>1</td>
      <td>Brick and Mortar</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2023-06-12</td>
      <td>-5591079094253810000</td>
      <td>-3971618995716690000</td>
      <td>-4612109181828620000</td>
      <td>3357108323404969175</td>
      <td>-3145342290914690000</td>
      <td>BLACK</td>
      <td>-4199173001801520000</td>
      <td>BLK</td>
      <td>BLACK</td>
      <td>...</td>
      <td>REGULAR</td>
      <td>FASHION</td>
      <td>FASHION</td>
      <td>L</td>
      <td>MENS</td>
      <td>TOPS</td>
      <td>32.88</td>
      <td>1.21</td>
      <td>1</td>
      <td>Brick and Mortar</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 21 columns</p>
</div>




```python
# Extract year and month from TRANSACTION_DATE
merged_data['YearMonth'] = merged_data['TRANSACTION_DATE'].dt.to_period('M')

```


```python
# Group by YearMonth and sum NET_SALES_UNITS
monthly_sales = merged_data.groupby('YearMonth')['NET_SALES_UNITS'].sum().reset_index()

# Convert YearMonth to datetime for plotting
monthly_sales['YearMonth'] = monthly_sales['YearMonth'].dt.to_timestamp()

```


```python
# Plot monthly sales
plt.figure(figsize=(12, 6))
plt.plot(monthly_sales['YearMonth'], monthly_sales['NET_SALES_UNITS'], color='lightblue', marker='o')
plt.title('Monthly Sales')
plt.xlabel('Month')
plt.ylabel('Total Sales Units')
plt.grid(True)
plt.show()

```


    
![png](output_26_0.png)
    



```python
# Ensure monthly data is sorted correctly for each year
sales_2022 = monthly_sales[monthly_sales['YearMonth'].dt.year == 2022].set_index('YearMonth')
sales_2023 = monthly_sales[monthly_sales['YearMonth'].dt.year == 2023].set_index('YearMonth')

# Reset the index to month for better plotting
sales_2022.index = sales_2022.index.month
sales_2023.index = sales_2023.index.month

# Plot both years on the same chart
plt.figure(figsize=(12, 6))
plt.plot(sales_2022.index, sales_2022['NET_SALES_UNITS'], color='darkblue', marker='o', label='2022')
plt.plot(sales_2023.index, sales_2023['NET_SALES_UNITS'], color='lightblue', marker='o', label='2023')
plt.title('Monthly Sales Comparison for 2022 and 2023')
plt.xlabel('Month')
plt.ylabel('Total Sales Units')
plt.xticks(range(1, 13), ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'])
plt.legend()
plt.grid(True)
plt.show()


```


    
![png](output_27_0.png)
    



```python
# Extract quarter from TRANSACTION_DATE
merged_data['YearQuarter'] = merged_data['TRANSACTION_DATE'].dt.to_period('Q')

```


```python
# Group by YearQuarter and sum NET_SALES_UNITS
quarterly_sales = merged_data.groupby('YearQuarter')['NET_SALES_UNITS'].sum().reset_index()

# Convert YearQuarter to datetime for plotting
quarterly_sales['YearQuarter'] = quarterly_sales['YearQuarter'].dt.to_timestamp()

```


```python
# Ensure quarterly data is sorted correctly for each year
sales_2022_q = quarterly_sales[quarterly_sales['YearQuarter'].dt.year == 2022].set_index('YearQuarter')
sales_2023_q = quarterly_sales[quarterly_sales['YearQuarter'].dt.year == 2023].set_index('YearQuarter')

# Reset the index to quarter for better plotting
sales_2022_q.index = sales_2022_q.index.quarter
sales_2023_q.index = sales_2023_q.index.quarter

# Plot both years on the same chart
plt.figure(figsize=(12, 6))
plt.plot(sales_2022_q.index, sales_2022_q['NET_SALES_UNITS'], color='darkblue', marker='o', label='2022')
plt.plot(sales_2023_q.index, sales_2023_q['NET_SALES_UNITS'], color='lightblue', marker='o', label='2023')
plt.title('Quarterly Sales Comparison for 2022 and 2023')
plt.xlabel('Quarter')
plt.ylabel('Total Sales Units')
plt.xticks(range(1, 5), ['Q1', 'Q2', 'Q3', 'Q4'])
plt.legend()
plt.grid(True)
plt.show()

```


    
![png](output_30_0.png)
    

